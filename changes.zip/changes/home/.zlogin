. ~/.tel/.tel_login
